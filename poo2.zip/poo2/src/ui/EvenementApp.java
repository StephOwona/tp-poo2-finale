package ui;

import model.*;
import service.GestionEvenements;
import exception.*;
import persistence.JsonUtil;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.time.LocalDateTime;
import java.util.Collections;
import java.util.List;

public class EvenementApp extends JFrame {
    private JTextField idField = new JTextField(10);
    private JTextField nomField = new JTextField(10);
    private JTextField lieuField = new JTextField(10);
    private JTextField capaciteField = new JTextField(5);

    private JTextField participantIdField = new JTextField(10);
    private JTextField participantNomField = new JTextField(10);
    private JTextField participantEmailField = new JTextField(15);
    private JTextField eventIdToCancelField = new JTextField(10);

    private JTextArea outputArea = new JTextArea(10, 40);

    public EvenementApp() {
        setTitle("Gestion Événements");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Formulaire création événement
        JPanel formPanel = new JPanel(new GridLayout(5, 2));
        formPanel.setBorder(BorderFactory.createTitledBorder("Nouvelle Conférence"));
        formPanel.add(new JLabel("ID:")); formPanel.add(idField);
        formPanel.add(new JLabel("Nom:")); formPanel.add(nomField);
        formPanel.add(new JLabel("Lieu:")); formPanel.add(lieuField);
        formPanel.add(new JLabel("Capacité:")); formPanel.add(capaciteField);

        JButton addButton = new JButton("Ajouter Conférence");
        addButton.addActionListener(this::ajouterEvenement);
        formPanel.add(addButton);

        // Formulaire inscription participant
        JPanel participantPanel = new JPanel(new GridLayout(4, 2));
        participantPanel.setBorder(BorderFactory.createTitledBorder("Inscription Participant"));
        participantPanel.add(new JLabel("ID Participant:")); participantPanel.add(participantIdField);
        participantPanel.add(new JLabel("Nom:")); participantPanel.add(participantNomField);
        participantPanel.add(new JLabel("Email:")); participantPanel.add(participantEmailField);

        JButton inscrireButton = new JButton("Inscrire");
        inscrireButton.addActionListener(this::inscrireParticipant);
        participantPanel.add(inscrireButton);

        // Annulation d'événement
        JPanel cancelPanel = new JPanel(new GridLayout(2, 2));
        cancelPanel.setBorder(BorderFactory.createTitledBorder("Annuler Événement"));
        cancelPanel.add(new JLabel("ID de l'événement:"));
        cancelPanel.add(eventIdToCancelField);

        JButton cancelButton = new JButton("Annuler");
        cancelButton.addActionListener(this::annulerEvenement);
        cancelPanel.add(cancelButton);

        // Sauvegarde JSON
        JButton saveButton = new JButton("Sauvegarder en JSON");
        saveButton.addActionListener(this::sauvegarderEvenements);

        JPanel bottomPanel = new JPanel();
        bottomPanel.add(saveButton);

        JPanel centerPanel = new JPanel(new BorderLayout());
        centerPanel.add(new JScrollPane(outputArea), BorderLayout.CENTER);

        JPanel forms = new JPanel(new GridLayout(1, 3));
        forms.add(formPanel);
        forms.add(participantPanel);
        forms.add(cancelPanel);

        add(forms, BorderLayout.NORTH);
        add(centerPanel, BorderLayout.CENTER);
        add(bottomPanel, BorderLayout.SOUTH);

        pack();
        setVisible(true);
    }

    private void ajouterEvenement(ActionEvent e) {
        try {
            String id = idField.getText();
            String nom = nomField.getText();
            String lieu = lieuField.getText();
            int capacite = Integer.parseInt(capaciteField.getText());

            Conference conf = new Conference(id, nom, LocalDateTime.now().plusDays(1), lieu, capacite, "POO", Collections.emptyList());
            GestionEvenements.getInstance().ajouterEvenement(conf);
            outputArea.append("✅ Conférence ajoutée: " + nom + "\n");
        } catch (EvenementDejaExistantException ex) {
            outputArea.append("❌ Erreur: événement déjà existant\n");
        } catch (NumberFormatException ex) {
            outputArea.append("❌ Erreur: capacité invalide\n");
        }
    }

    private void inscrireParticipant(ActionEvent e) {
        String id = participantIdField.getText();
        String nom = participantNomField.getText();
        String email = participantEmailField.getText();
        String eventId = idField.getText();

        Participant p = new Participant(id, nom, email);
        Evenement evt = GestionEvenements.getInstance().rechercherEvenement(eventId);

        if (evt == null) {
            outputArea.append("❌ Événement non trouvé pour l'ID: " + eventId + "\n");
            return;
        }

        try {
            evt.ajouterParticipant(p);
            outputArea.append(" Participant inscrit à " + evt.getNom() + "\n");
        } catch (CapaciteMaxAtteinteException ex) {
            outputArea.append(" Capacité maximale atteinte pour " + evt.getNom() + "\n");
        }
    }

    private void annulerEvenement(ActionEvent e) {
        String id = eventIdToCancelField.getText();
        Evenement evt = GestionEvenements.getInstance().rechercherEvenement(id);
        if (evt != null) {
            evt.annuler();
            outputArea.append(" Événement " + evt.getNom() + " annulé.\n");
        } else {
            outputArea.append(" Aucun événement trouvé avec ID: " + id + "\n");
        }
    }

    private void sauvegarderEvenements(ActionEvent e) {
        try {
            List<Evenement> liste = GestionEvenements.getInstance().getTousEvenements();
            JsonUtil.sauvegarder("evenements.json", liste);
            outputArea.append(" Événements sauvegardés dans evenements.json\n");
        } catch (Exception ex) {
            outputArea.append(" Erreur lors de la sauvegarde JSON\n");
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(EvenementApp::new);
    }
}
