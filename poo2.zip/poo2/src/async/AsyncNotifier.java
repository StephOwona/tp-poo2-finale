package async;

import java.util.concurrent.CompletableFuture;
import model.Participant;

public class AsyncNotifier {
    public static void envoyerNotificationAsync(Participant participant, String message) {
        CompletableFuture.runAsync(() -> {
            try {
                Thread.sleep(1000); // Simule un délai
                participant.notifier("[Async] " + message);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        });
    }
}

