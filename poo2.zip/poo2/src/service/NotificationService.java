package service;

public interface NotificationService {
    void envoyerNotification(String message);
}
