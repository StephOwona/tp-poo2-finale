package model;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import observer.ParticipantObserver;
import exception.CapaciteMaxAtteinteException;
import observer.EvenementObservable;

public abstract class Evenement {
    protected String id;
    protected String nom;
    protected LocalDateTime date;
    protected String lieu;
    protected int capaciteMax;
    protected List<Participant> participants = new ArrayList<>();
    protected EvenementObservable observable = new EvenementObservable();

    public Evenement(String id, String nom, LocalDateTime date, String lieu, int capaciteMax) {
        this.id = id;
        this.nom = nom;
        this.date = date;
        this.lieu = lieu;
        this.capaciteMax = capaciteMax;
    }

    public void ajouterParticipant(Participant p) throws CapaciteMaxAtteinteException {
        if (participants.size() >= capaciteMax) {
            throw new CapaciteMaxAtteinteException("Capacité maximale atteinte.");
        }
        participants.add(p);
        observable.ajouterObserver(p);
    }

    public void afficherDetails() {
        System.out.println("Événement : " + nom + " au " + lieu + " le " + date);
    }

    public abstract void annuler();

    public String getId() { return id; }
    public String getNom() { return nom; }
    public List<Participant> getParticipants() { return participants; }
}
