package model;

public class Intervenant {
    private String nom;

    public Intervenant(String nom) {
        this.nom = nom;
    }

    public String getNom() { return nom; }
}
