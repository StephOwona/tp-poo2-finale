import model.*;
import service.GestionEvenements;
import exception.*;
import persistence.JsonUtil;
import async.AsyncNotifier;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;

public class Main {
    public static void main(String[] args) throws Exception {
        Participant p1 = new Participant("P1", "Alice", "alice@mail.com");
        Intervenant int1 = new Intervenant("Dr. Dupont");

        Conference conf = new Conference("C1", "Conf Java", LocalDateTime.now().plusDays(5), "ENSPY", 100, "Java et POO", Arrays.asList(int1));
        conf.ajouterParticipant(p1);

        GestionEvenements gestion = GestionEvenements.getInstance();
        gestion.ajouterEvenement(conf);

        conf.afficherDetails();

        // Notification asynchrone
        AsyncNotifier.envoyerNotificationAsync(p1, "Rappel : votre événement commence bientôt");

        // Sauvegarde JSON
        JsonUtil.sauvegarder("evenements.json", List.of(conf));

        // Chargement JSON (affiche le nom du premier événement)
        List<Evenement> charges = JsonUtil.charger("evenements.json");
        System.out.println("Événement chargé : " + charges.get(0).getNom());

        conf.annuler();
    }
}
