package observer;

public interface ParticipantObserver {
    void notifier(String message);
}