package persistence;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import model.Evenement;

import java.io.File;
import java.io.IOException;
import java.util.Collection;
import java.util.List;

public class JsonUtil {
    private static final ObjectMapper mapper = new ObjectMapper()
            .findAndRegisterModules()
            .enable(SerializationFeature.INDENT_OUTPUT);

    public static void sauvegarder(String chemin, Collection<Evenement> evenements) throws IOException {
        mapper.writeValue(new File(chemin), evenements);
    }

    public static List<Evenement> charger(String chemin) throws IOException {
        return List.of(mapper.readValue(new File(chemin), Evenement[].class));
    }
}


