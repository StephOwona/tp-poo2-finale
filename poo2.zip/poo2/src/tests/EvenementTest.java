package tests;

import model.*;
import exception.*;
import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;
import java.util.Collections;

import static org.junit.jupiter.api.Assertions.*;

public class EvenementTest {
    @Test
    public void testInscriptionEtNotification() throws Exception {
        Participant p = new Participant("P1", "Bob", "bob@mail.com");
        Conference c = new Conference("C1", "Java Conf", LocalDateTime.now().plusDays(1), "ENSPY", 2, "POO", Collections.emptyList());
        c.ajouterParticipant(p);
        assertEquals(1, c.getParticipants().size());
    }

    @Test
    public void testCapaciteMaxException() {
        assertThrows(CapaciteMaxAtteinteException.class, () -> {
            Participant p1 = new Participant("P1", "Bob", "bob@mail.com");
            Participant p2 = new Participant("P2", "Alice", "alice@mail.com");
            Conference c = new Conference("C2", "Conf", LocalDateTime.now(), "ENSPY", 1, "Thème", Collections.emptyList());
            c.ajouterParticipant(p1);
            c.ajouterParticipant(p2); // Doit échouer
        });
    }

    @Test
    public void testEvenementDejaExistantException() throws Exception {
        GestionEvenements gestion = GestionEvenements.getInstance();
        Conference c = new Conference("C3", "Conf", LocalDateTime.now(), "ENSPY", 10, "Thème", Collections.emptyList());
        gestion.ajouterEvenement(c);
        assertThrows(EvenementDejaExistantException.class, () -> {
            gestion.ajouterEvenement(c);
        });
    }
}
